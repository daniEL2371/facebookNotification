/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FaceBookNotification;

/**
 *
 * @author Daniel Zelalem
 * ATR/2026/08
 */
import java.util.List;
import java.util.Scanner;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FaceBookNotification {
   
    
    public static void main(String[] args) {
        System.out.print("Enter your email or phone: ");
        String email = new Scanner(System.in).next();
        System.out.print("Enter your password: ");
        String pass = new Scanner(System.in).next();
        System.out.println();
        startRoutine(email, pass);
        
      
    }
    public static void startRoutine(String email,String password) {
        String notification;
        String friendRequest;
        String message;
        System.setProperty("webdriver.chrome.driver","C:\\Users\\hp255-g3\\Downloads\\selinium\\chromedriver.exe");
        ChromeDriver driver;
        System.setProperty("webdriver.chrome.driver","C:\\Users\\hp255-g3\\Downloads\\selinium\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http:/facebook.com/");
        WebElement emailText = driver.findElementById("email");
        WebElement pass = driver.findElementById("pass");
        WebElement btn = driver.findElementById("u_0_2");
        
        emailText.sendKeys(email);
        pass.sendKeys(password);
        btn.click();
        
        notification = driver.findElementById("notificationsCountValue").getText();
        friendRequest = driver.findElementById("requestsCountValue").getText();
        message = driver.findElementById("mercurymessagesCountValue").getText();
        printResults(notification, friendRequest, message);
        //password.get(0).click();
        try {
            Thread.sleep(1000);
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        
    }
    public static void printResults(String notification, String friendRequest, String message) {
        try {
            Integer.parseInt(notification);
        } catch(Exception ex) {
            notification = "0";
        }
        try {
            Integer.parseInt(friendRequest);
        } catch(Exception ex) {
            friendRequest = "0";
        }
        try {
            Integer.parseInt(message);
        } catch(Exception ex) {
            message = "0";
        }
        System.out.println("You have " + notification + " notifications");
        System.out.println("You have " + message + " messages");
        System.out.println("You have " + friendRequest + " friend requests");
    }
    
}
